/*  HOW TO PLAY:
    LEVEL 1: shoot 10 animals by hitting B
    LEVEL 2: all the bats are in the top left corner when the game starts, so avoid the witches and go there to get candy first.
        once you have some candy, start shooting the witches by pressing A till some animals come up, and then it's just like level one.
        so then just shoot 10 animals to win the level.
    LEVEL 3: collect all 10 bats to win but make sure to avoid the witches completely - candy to kill them is scattered about the map
    ... or just press R and use the cheat ._.
*/

#include <stdlib.h>
#include <stdio.h>

// code files
#include "myLib.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"

// images for state machine
#include "scoreForeground.h"
#include "scoreForegroundLevel3.h"
#include "start.h"
#include "movingBackgroundMaybe.h"
#include "inst1.h"
#include "inst2.h"
#include "level2Inst.h"
#include "level3Inst.h"
#include "pause.h"
#include "pauseForeground.h"
#include "win.h"
#include "winForeground.h"
#include "lose.h"
#include "spritesheet.h"

// maps
#include "level1Map.h"
#include "level2Map.h"
#include "level3Map.h"

// sound
#include "sound.h"
#include "introSong.h"
#include "gamePlaySong.h"
#include "pauseSong.h"
#include "winSong.h"
#include "loseSong.h"
#include "longerWitchLaugh.h"
#include "click.h"


// Prototypes
void initialize();

// State Prototypes
void goToStart();
void start();

void goToInst1();
void inst1();
void goToInst2();
void inst2();

void goToLevel1();
void level1();

void goToLevel2Inst();
void level2Inst();

void goToLevel2();
void level2();

void goToLevel3Inst();
void level3Inst();

void goToLevel3();
void level3();

void goToPause();
void pause();

void goToWin();
void win();

void goToLose();
void lose();

// sprite functions for state screens 
void drawStartGhost();

void initBear(int, int);
void drawBear();
void animateBear();

void initPauseBear();
void drawPauseBear();
void animatePauseBear();

void initSprites(ANISPRITE *, int, int);
void animateSprites(ANISPRITE *);
void moveSpriteUpAndDown(ANISPRITE *, int, int);

void drawWitchesMain(ANISPRITE *);
void drawGhosts(ANISPRITE *);
void drawBatsMain(ANISPRITE *);
void drawDancingGhost(ANISPRITE *);
void drawCryingBats(ANISPRITE *);

// sprite for animated ghost on start screen
// uses player functions
ANISPRITE ghost;

// sprites on the state screens
// use functions at the bottom of main (mostly)
ANISPRITE ghost1;
ANISPRITE ghost2;
ANISPRITE ghost3;

ANISPRITE dancingGhost;
ANISPRITE dancingGhost2;

ANISPRITE bat1;
ANISPRITE bat2;
ANISPRITE bat3;
ANISPRITE bat4;

ANISPRITE witch1;

ANIMALS bear;
ANIMALS pauseBear;

ANISPRITE candy1;

int shadowOAMIndex;

// to keep track of levels for pause function
int level;

// variables for parallax background movement
int screenAniCounter;
int bgHOff;



// States
enum
{
    START,
    INST1,
    INST2,
    LEVEL1,
    LEVEL2INST,
    LEVEL2,
    LEVEL3INST,
    LEVEL3,
    PAUSE,
    WIN,
    LOSE
};
int state;

SOUND soundA;
SOUND soundB;

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Shadow OAM
OBJ_ATTR shadowOAM[128];

int main()
{
    initialize();

    while (1)
    {
        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch (state)
        {
        case START:
            start();
            break;
        case INST1:
            inst1();
            break;
        case INST2:
            inst2();
            break;
        case LEVEL1:
            level1();
            break;
        case LEVEL2INST:
            level2Inst();
            break;
        case LEVEL2:
            level2();
            break;
        case LEVEL3INST:
            level3Inst();
            break;
        case LEVEL3:
            level3();
            break;
        case PAUSE:
            pause();
            break;
        case WIN:
            win();
            break;
        case LOSE:
            lose();
            break;
        }
    }
}

// Sets up GBA
void initialize()
{
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | BG3_ENABLE | SPRITE_ENABLE;
    REG_BG0CNT =  BG_SIZE_SMALL | BG_CHARBLOCK(0) | BG_SCREENBLOCK(31); // start, instructions, win, and score foreground
    REG_BG1CNT =  BG_SIZE_WIDE | BG_CHARBLOCK(1) | BG_SCREENBLOCK(28); // game
    // no more background 2 bc foreground doesn't work :(
    REG_BG3CNT = BG_SIZE_SMALL | BG_CHARBLOCK(3) | BG_SCREENBLOCK(22); // lose, pause, movingBackground on start screen, win foregorund, and pause foreground

    buttons = BUTTONS;
    oldButtons = 0;

    setupSounds();
	setupInterrupts();

    goToStart();
}

// Sets up the start state
void goToStart() {
    waitForVBlank();

    REG_DISPCTL = MODE0 | BG0_ENABLE | BG3_ENABLE | SPRITE_ENABLE;

    // foreground
    DMANow(3, startPal, PALETTE, 256);
    DMANow(3, startTiles, &CHARBLOCK[0], startTilesLen / 2);
    DMANow(3, startMap, &SCREENBLOCK[31], startMapLen / 2);
    REG_BG0VOFF = 0;
    REG_BG0HOFF = 0;

    // parallax background
    DMANow(3, movingBackgroundMaybePal, PALETTE, 256);
    DMANow(3, movingBackgroundMaybeTiles, &CHARBLOCK[3], movingBackgroundMaybeTilesLen / 2);
    DMANow(3, movingBackgroundMaybeMap, &SCREENBLOCK[22], movingBackgroundMaybeMapLen / 2);
    REG_BG3VOFF = 0;
    REG_BG3HOFF = 0;


    stopSound();  
	playSoundA(introSong_data, introSong_length, 1);

    // load sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    // init sprites to orginal starting position
    initPlayer(115, 96);
    initBear(23, 103);
    
    state = START;
}

// Runs every frame of the start state
void start() {
    // keep the parallax background moving every 20 frames
    screenAniCounter++;
    if (screenAniCounter % 20 == 0) {
        bgHOff++;
        REG_BG3HOFF = bgHOff;
    }
    
    // animate and draw the ghost and bear on the starting screen
    animatePlayer();
    animateBear();

    shadowOAMIndex = 0;
    hideSprites();

    drawGhosts(&ghost);
    drawBear();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();
        playSoundA(gamePlaySong_data, gamePlaySong_length, 1);

        goToLevel1();
        initLevel1();
    }
    if (BUTTON_PRESSED(BUTTON_SELECT)) {
        playSoundB(click_data, click_length, 0);
        goToInst1();
    }
    if (BUTTON_PRESSED(BUTTON_L)) {
        stopSound();
        playSoundA(winSong_data, winSong_length, 1);
        goToWin();
    }
}

void goToInst1() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    DMANow(3, inst1Pal, PALETTE, 256);
    DMANow(3, inst1Tiles, &CHARBLOCK[0], inst1TilesLen / 2);
    DMANow(3, inst1Map, &SCREENBLOCK[31], inst1MapLen / 2);

    // init sprites for animation
    initSprites(&witch1, 193, 99);
    initSprites(&ghost1, 205, 17);

    state = INST1;
}

void inst1() {
    // animate and draw ghost and bats on inst screen
    animateSprites(&witch1);
    animateSprites(&ghost1);

    shadowOAMIndex = 0;
    hideSprites();

    drawWitchesMain(&witch1);
    drawGhosts(&ghost1);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        playSoundB(click_data, click_length, 0);
        goToInst2();
    }
}

void goToInst2() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    DMANow(3, inst2Pal, PALETTE, 256);
    DMANow(3, inst2Tiles, &CHARBLOCK[0], inst1TilesLen / 2);
    DMANow(3, inst2Map, &SCREENBLOCK[31], inst1MapLen / 2);

    // init sprites for animation
    initSprites(&bat1, 20, 72);

    // animated candy piece
    candy1.worldCol = 39;
    candy1.worldRow = 80;
    candy1.width = 16;
    candy1.height = 16;
    candy1.aniCounter = 0;
    candy1.curFrame = 0;
    candy1.numFrames = 4;

    state = INST2;
}

void inst2() {
    // animate and draw bat
    animateSprites(&bat1);
    animateSprites(&candy1);

    shadowOAMIndex = 0;
    hideSprites();

    drawBatsMain(&bat1);

    // animated candy piece
    shadowOAM[shadowOAMIndex].attr0 = candy1.worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = candy1.worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((candy1.curFrame * 2) + 18, 4);
    shadowOAMIndex++;

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_LEFT)) {
        playSoundB(click_data, click_length, 0);
        goToInst1();
    }
    if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(gamePlaySong_data, gamePlaySong_length, 1);

        goToLevel1();
        initLevel1();
    }
}

// Sets up the game state
void goToLevel1() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG1_ENABLE | BG0_ENABLE | SPRITE_ENABLE;

    // map background
    DMANow(3, level1MapPal, PALETTE, 256);
    DMANow(3, level1MapTiles, &CHARBLOCK[1], level1MapTilesLen / 2);
    DMANow(3, level1MapMap, &SCREENBLOCK[28], level1MapMapLen / 2);
    REG_BG1VOFF = vOff;
    REG_BG1HOFF = hOff;

    // foreground for the score
    DMANow(3, scoreForegroundTiles, &CHARBLOCK[0], scoreForegroundTilesLen / 2);
    DMANow(3, scoreForegroundMap, &SCREENBLOCK[31], scoreForegroundMapLen / 2);
    REG_BG0VOFF = 0;
    REG_BG0HOFF = 0;

    // sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = LEVEL1;
    level = 1;
}

// Runs every frame of the game state
void level1() {
    updateLevel1();
    drawLevel1();

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(pauseSong_data, pauseSong_length, 1);

        goToPause();
    }
    if (lostLevel1 == 1) {
        stopSound();  
        playSoundB(longerWitchLaugh_data, longerWitchLaugh_length, 0);
	    playSoundA(loseSong_data, loseSong_length, 1);

        goToLose();
    }
    if (wonLevel1 == 1) {
        stopSound();  
	    playSoundA(introSong_data, introSong_length, 1);

        goToLevel2Inst();
    }
}

void goToLevel2Inst() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    DMANow(3, level2InstPal, PALETTE, 256);
    DMANow(3, level2InstTiles, &CHARBLOCK[0], level2InstTilesLen / 2);
    DMANow(3, level2InstMap, &SCREENBLOCK[31], level2InstMapLen / 2);

    // init sprites for animation
    initSprites(&witch1, 198, 20);
    initSprites(&bat1, 63, 136);
    initSprites(&bat2, 160, 136);

    state = LEVEL2INST;
}

void level2Inst() {
    // draw and animate sprites
    animateSprites(&witch1);
    animateSprites(&bat1);
    animateSprites(&bat2);

    shadowOAMIndex = 0;
    hideSprites();

    drawWitchesMain(&witch1);
    drawBatsMain(&bat1);
    drawBatsMain(&bat2);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(gamePlaySong_data, gamePlaySong_length, 1);

        goToLevel2();
        initLevel2();
    }
}

// Sets up the game state
void goToLevel2() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG1_ENABLE | BG0_ENABLE | SPRITE_ENABLE;

    //map background
    DMANow(3, level2MapPal, PALETTE, 256);
    DMANow(3, level2MapTiles, &CHARBLOCK[1], level2MapTilesLen / 2);
    DMANow(3, level2MapMap, &SCREENBLOCK[28], level2MapMapLen / 2);
    REG_BG1VOFF = vOff;
    REG_BG1HOFF = hOff;

    //foreground for the score
    DMANow(3, scoreForegroundTiles, &CHARBLOCK[0], scoreForegroundTilesLen / 2);
    DMANow(3, scoreForegroundMap, &SCREENBLOCK[31], scoreForegroundMapLen / 2);
    REG_BG0VOFF = 0;
    REG_BG0HOFF = 0;

    //sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    level = 2;
    state = LEVEL2;
}

// Runs every frame of the game state
void level2() {
    updateLevel2();
    drawLevel2();

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(pauseSong_data, pauseSong_length, 1);

        goToPause();
    }
    if (lostLevel2 == 1) {
        stopSound();
        playSoundB(longerWitchLaugh_data, longerWitchLaugh_length, 0);
	    playSoundA(loseSong_data, loseSong_length, 1);

        goToLose();
    }
    if (wonLevel2 == 1) {
        stopSound();  
	    playSoundA(introSong_data, introSong_length, 1);

        goToLevel3Inst();;
    }
}

void goToLevel3Inst() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    DMANow(3, level3InstPal, PALETTE, 256);
    DMANow(3, level3InstTiles, &CHARBLOCK[0], level3InstTilesLen / 2);
    DMANow(3, level3InstMap, &SCREENBLOCK[31], level3InstMapLen / 2);

    // init sprites for animation
    initSprites(&witch1, 180, 51);
    initSprites(&bat1, 63, 136);
    initSprites(&bat2, 160, 136);

    state = LEVEL3INST;
}

void level3Inst() {
    // animate and draw sprites
    animateSprites(&witch1);
    animateSprites(&bat1);
    animateSprites(&bat2);

    shadowOAMIndex = 0;
    hideSprites();

    drawWitchesMain(&witch1);
    drawBatsMain(&bat1);
    drawBatsMain(&bat2);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(gamePlaySong_data, gamePlaySong_length, 1);
        
        goToLevel3();
        initLevel3();
    }
}

// Sets up the game state
void goToLevel3() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG1_ENABLE | BG0_ENABLE | SPRITE_ENABLE;

    //map background
    DMANow(3, level3MapPal, PALETTE, 256);
    DMANow(3, level3MapTiles, &CHARBLOCK[1], level3MapTilesLen / 2);
    DMANow(3, level3MapMap, &SCREENBLOCK[28], level3MapMapLen / 2);
    REG_BG1VOFF = vOff;
    REG_BG1HOFF = hOff;

    //foreground for the score
    DMANow(3, scoreForegroundLevel3Tiles, &CHARBLOCK[0], scoreForegroundLevel3TilesLen / 2);
    DMANow(3, scoreForegroundLevel3Map, &SCREENBLOCK[31], scoreForegroundLevel3MapLen / 2);
    REG_BG0VOFF = 0;
    REG_BG0HOFF = 0;

    //sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    level = 3;
    state = LEVEL3;
}

// Runs every frame of the game state
void level3() {
    updateLevel3();
    drawLevel3();

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(pauseSong_data, pauseSong_length, 1);

        goToPause();
    }
    if (lostLevel3 == 1) {
        stopSound();
        playSoundB(longerWitchLaugh_data, longerWitchLaugh_length, 0);
	    playSoundA(loseSong_data, loseSong_length, 1);

        goToLose();
    }
    if (wonLevel3 == 1) {
        stopSound();
        playSoundA(winSong_data, winSong_length, 1);

        goToWin();
    }
}

// Sets up the pause state
void goToPause() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG3_ENABLE | SPRITE_ENABLE;
    // main pause screen
    DMANow(3, pausePal, PALETTE, 256);
    DMANow(3, pauseTiles, &CHARBLOCK[0], pauseTilesLen / 2);
    DMANow(3, pauseMap, &SCREENBLOCK[31], pauseMapLen / 2);
    REG_BG0HOFF = 0;
    REG_BG0VOFF = 0;

    // moving foreground
    DMANow(3, pauseForegroundPal, PALETTE, 256);
    DMANow(3, pauseForegroundTiles, &CHARBLOCK[3], pauseForegroundTilesLen / 2);
    DMANow(3, pauseForegroundMap, &SCREENBLOCK[22], pauseForegroundMapLen / 2);
    REG_BG3VOFF = 0;
    REG_BG3HOFF = 0;

    // init pause bear eating pie ._.
    initPauseBear();

    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {
    // keep lights from foregorund moving at top
    screenAniCounter++;
    if (screenAniCounter % 20 == 0) {
        bgHOff++;
        REG_BG3HOFF = bgHOff;
    }
    // animate and draw pause bear eating pie ._.
    animatePauseBear();

    shadowOAMIndex = 0;
    hideSprites();

    drawPauseBear();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();
        playSoundB(click_data, click_length, 0);
        playSoundA(gamePlaySong_data, gamePlaySong_length, 1);

        if (level == 1) {
            goToLevel1();
        }
        if (level == 2) {
            goToLevel2();
        }
        if (level == 3) {
            goToLevel3();
        }
    }
    if (BUTTON_PRESSED(BUTTON_SELECT)) {
        stopSound();  
        playSoundB(click_data, click_length, 0);
	    playSoundA(introSong_data, introSong_length, 1);

        goToStart();
    }
}

// Sets up the win state
void goToWin() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG0_ENABLE | BG3_ENABLE | SPRITE_ENABLE;
    // main win background
    DMANow(3, winPal, PALETTE, 256);
    DMANow(3, winTiles, &CHARBLOCK[0], winTilesLen / 2);
    DMANow(3, winMap, &SCREENBLOCK[31], winMapLen / 2);
    REG_BG0HOFF = 0;
    REG_BG0VOFF = 0;

    // moving foreground
    DMANow(3, winForegroundPal, PALETTE, 256);
    DMANow(3, winForegroundTiles, &CHARBLOCK[3], winForegroundTilesLen / 2);
    DMANow(3, winForegroundMap, &SCREENBLOCK[22], winForegroundMapLen / 2);
    REG_BG3VOFF = 0;
    REG_BG3HOFF = 0;

    // init the dancing sprites!!
    dancingGhost.width = 32;
    dancingGhost.height = 16;
    dancingGhost.worldCol = 24;
    dancingGhost.worldRow = 104;
    dancingGhost.aniCounter = 0;
    dancingGhost.curFrame = 0;
    dancingGhost.numFrames = 8;

    dancingGhost2.width = 32;
    dancingGhost2.height = 16;
    dancingGhost2.worldCol = 88;
    dancingGhost2.worldRow = 64;
    dancingGhost2.aniCounter = 0;
    dancingGhost2.curFrame = 5;
    dancingGhost2.numFrames = 8;

    initSprites(&ghost1, 186, 68);
    initSprites(&bat1, 19, 32);
    initSprites(&bat2, 51, 72);
    initSprites(&bat3, 192, 28);
    initSprites(&bat4, 216, 105);
    initBear(210, 147);

    state = WIN;
}

// Runs every frame of the win state
void win() {
    // keep lights moving from foreground at top
    screenAniCounter++;
    if (screenAniCounter % 5 == 0) {
        bgHOff++;
        REG_BG3HOFF = bgHOff;
    }

    // amimate, draw, and move all the dancing sprites!!
    animateSprites(&dancingGhost);
    animateSprites(&dancingGhost2);
    animateBear();
    animateSprites(&ghost1);
    animateSprites(&bat1);
    animateSprites(&bat2);
    animateSprites(&bat3);
    animateSprites(&bat4);

    moveSpriteUpAndDown(&ghost1, 60, 127);
    moveSpriteUpAndDown(&bat1, 23, 54);
    moveSpriteUpAndDown(&bat2, 61, 100);
    moveSpriteUpAndDown(&bat3, 5, 50);
    moveSpriteUpAndDown(&bat4, 81, 135);
    
    shadowOAMIndex = 0;
    hideSprites();

    drawDancingGhost(&dancingGhost);
    drawDancingGhost(&dancingGhost2);
    drawGhosts(&ghost1);
    drawBear();
    drawBatsMain(&bat1);
    drawBatsMain(&bat2);
    drawBatsMain(&bat3);
    drawBatsMain(&bat4);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();  
        playSoundB(click_data, click_length, 0);
	    playSoundA(introSong_data, introSong_length, 1);

        goToStart();
    }
}

// Sets up the lose state
void goToLose() {
    waitForVBlank();
    REG_DISPCTL = MODE0 | BG3_ENABLE | SPRITE_ENABLE;
    DMANow(3, losePal, PALETTE, 256);
    DMANow(3, loseTiles, &CHARBLOCK[3], loseTilesLen / 2);
    DMANow(3, loseMap, &SCREENBLOCK[22], loseMapLen / 2);
    REG_BG3HOFF = 0;
    REG_BG3VOFF = 0;

    // init crying bats
    initSprites(&bat1, 13, 100);
    initSprites(&bat2, 121, 65);

    state = LOSE;
}

// Runs every frame of the lose state
void lose() {

    // functions to make bats crying flying up and down
    animateSprites(&bat1);
    animateSprites(&bat2);

    moveSpriteUpAndDown(&bat1, 60, 144);
    moveSpriteUpAndDown(&bat2, 55, 115);

    shadowOAMIndex = 0;
    hideSprites();

    drawCryingBats(&bat1);
    drawCryingBats(&bat2);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    if (BUTTON_PRESSED(BUTTON_START)) {
        stopSound();  
        playSoundB(click_data, click_length, 0);
	    playSoundA(introSong_data, introSong_length, 1);

        if (level == 1) {
            goToStart();
        } else if (level == 2) {
            goToLevel2Inst();
        } else {
            goToLevel3Inst();
        }
    }
}



// sprite functions /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// functions for peeking bear on start and win screen

void initBear(int col, int row) {
    bear.worldCol = col;
    bear.worldRow = row;
    bear.width = 16;
    bear.height = 16;
    bear.spriteType = 1; // 1 for bear as bee (yellow), 2 for bunny as butterfly (purple), 3 for frog as mushrrom (green)
    bear.aniCounter = 0;
    bear.curFrame = 0;
    bear.numFrames = 15;
}

void drawBear() {
    shadowOAM[shadowOAMIndex].attr0 = bear.worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = bear.worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(bear.curFrame * 2, 10);
    shadowOAMIndex++;
}

// functions for bear on pause screen
void animateBear() {
    if(bear.aniCounter % 50 == 0) {
        bear.curFrame++;
        if (bear.curFrame == bear.numFrames) {
            bear.curFrame = 0;
        }
    }
    bear.aniCounter++;
}

void initPauseBear() {
    pauseBear.worldCol = 94;
    pauseBear.worldRow = 76;
    pauseBear.width = 64;
    pauseBear.height = 64;
    pauseBear.spriteType = 1; // 1 for bear as bee (yellow), 2 for bunny as butterfly (purple), 3 for frog as mushrrom (green)
    pauseBear.aniCounter = 0;
    pauseBear.curFrame = 0;
    pauseBear.numFrames = 8;
}

void drawPauseBear() {
    shadowOAM[shadowOAMIndex].attr0 = pauseBear.worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = pauseBear.worldCol | ATTR1_LARGE;
    if (pauseBear.curFrame < 4) {
        shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(pauseBear.curFrame * 8, 12);
    }
    else {
        shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((pauseBear.curFrame * 8) - 32, 20);
    }
    shadowOAMIndex++;
}

void animatePauseBear(){
    if(pauseBear.aniCounter % 30 == 0) {
        pauseBear.curFrame++;
        if (pauseBear.curFrame == pauseBear.numFrames) {
            pauseBear.curFrame = 0;
        }
    }
    pauseBear.aniCounter++;
}

// draw dancing ghost on win screen
void drawDancingGhost(ANISPRITE * dancingGhost) {
    shadowOAM[shadowOAMIndex].attr0 = dancingGhost->worldRow | ATTR0_WIDE;
    shadowOAM[shadowOAMIndex].attr1 = dancingGhost->worldCol| ATTR1_MEDIUM;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(dancingGhost->curFrame * 4, 28);
    shadowOAMIndex++;
}

// general functions for sprites on state screens
void animateSprites(ANISPRITE* sprite) {
    if (sprite->aniCounter % 20 == 0) {
        sprite->curFrame++;
        if (sprite->curFrame == sprite->numFrames) {
            sprite->curFrame = 0;
        }
    }
    sprite->aniCounter++;
}

void moveSpriteUpAndDown(ANISPRITE * sprite, int upperLimit, int lowerLimit) {
    if (sprite->facePos == 2) {
        if (sprite->worldRow + sprite->height + 1 < lowerLimit) {
            sprite->rdel = 1;
            sprite->cdel = 0;
        } else {
            sprite->facePos = 1;
        }
    }
    
    if (sprite->facePos == 1) {
        if (sprite->worldRow - 1 > upperLimit) {
            sprite->rdel = -1;
            sprite->cdel = 0;
        } else {
            sprite->facePos = 2;
        }
    }

    sprite->worldRow += sprite->rdel;
    sprite->worldCol += sprite->cdel;
}

void initSprites(ANISPRITE * sprite, int col, int row) {
    sprite->width = 16;
    sprite->height = 16;
    sprite->worldCol = col;
    sprite->worldRow = row;
    sprite->aniCounter = 0;
    sprite->curFrame = 0;
    sprite->numFrames = 2;
    sprite->facePos = 2; // 1 for moving up, 2 for moving down
}

// drawing ghosts
void drawGhosts(ANISPRITE * ghost) {
    shadowOAM[shadowOAMIndex].attr0 = ghost->worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = ghost->worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(2, ghost->curFrame * 2);
    shadowOAMIndex++;
}

// drawing bats
void drawBatsMain(ANISPRITE * bat) {
    shadowOAM[shadowOAMIndex].attr0 = bat->worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = bat->worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(10, (bat->curFrame * 2) + 4);
    shadowOAMIndex++;
}

void drawCryingBats(ANISPRITE * bat) {
    shadowOAM[shadowOAMIndex].attr0 = bat->worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = bat->worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(16, (bat->curFrame * 2) + 4);
    shadowOAMIndex++;
}

void drawWitchesMain(ANISPRITE * witch) {
    shadowOAM[shadowOAMIndex].attr0 = witch->worldRow | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = witch->worldCol | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(4, (witch->curFrame * 2) + 4);
    shadowOAMIndex++;
}
