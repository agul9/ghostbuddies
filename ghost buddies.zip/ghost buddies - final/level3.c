#include "myLib.h"
#include "level3.h"
#include "collisionmap3.h"

#include "sound.h"
#include "gotCandySound.h"
#include "happyBat.h"
#include "witchScream.h"
#include "witchLaugh.h"
#include "click.h"

// Variables
int hOff;
int vOff;
int cheatOn;
int candyCount;
int batBuddies;
int witchesOut;
int lostLevel3; // set to 1 when witch collides with ghost
int wonLevel3; // set to 1 when you rescue all the bats (batBuddies == BATCOUNT)

OBJ_ATTR shadowOAM[128];
int shadowOAMIndex;

// from lib.h in all levels
ANISPRITE ghost;
ATTACKSPRITE candy[20]; // array for candy that player has to shoot
ATTACKSPRITE knives[KNIVESCOUNT]; // only used when cheat is activated

// from level3.h specific to level 3
WITCH witches3[WITCHCOUNT3];
BATS bats3[BATCOUNT3];
ATTACKSPRITE candyPlaced[CANDYPLACEDCOUNT]; // array for candy that is placed around the map

unsigned char* collisionmap3 = collisionmap3Bitmap;

SOUND soundA;
SOUND soundB;

// ghost animation states for aniState
//enum {ghostDOWN, ghostUP, ghostRIGHT, ghostLEFT};

// Initialize the game
void initLevel3() {
    vOff = 96;
    hOff = 9;

    cheatOn = 0;
    candyCount = 0;
    batBuddies = 0;
    wonLevel3 = 0;
    lostLevel3 = 0;
    witchesOut = WITCHCOUNT3;

    initPlayer(115, 150);
    initAttackSprites();
    initWitches3();
    initBats3();
    initCandyPlaced();
}

// Updates the game each frame
void updateLevel3() {

	updatePlayer3();
    animatePlayer();
    animateCandyPlaced();

    for (int i = 0; i < BATCOUNT3; i++) {
        updateBats3(&bats3[i]);
        animateBats(&bats3[i]);
    }
    for (int i = 0; i < 20; i++) {
        updateCandy3(&candy[i]);
    }
    for (int i = 0; i < WITCHCOUNT3; i++) {
        updateWitches3(&witches3[i]);
        animateWitches(&witches3[i]);
    }
    for (int i = 0; i < CANDYPLACEDCOUNT; i++) {
        updateCandyPlaced(&candyPlaced[i]);
    }

    for (int i = 0; i < KNIVESCOUNT; i++) {
        updateKnives3(&knives[i]);
    }

    // only used for cheat
    for (int i = 0; i < KNIVESCOUNT; i++) {
        updateKnives3(&knives[i]);
    }
}

// Draws the game each frame
void drawLevel3() {
    shadowOAMIndex = 0; 
    drawPlayer();
    drawWitches3();
    drawKnives(); // only used for cheat
    drawCandy();
    drawBats3();
    drawCandyPlaced();
    drawScore3();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG1HOFF = hOff;
    REG_BG1VOFF = vOff;
}

// Handle every-frame actions of the player
void updatePlayer3() {
    if (batBuddies == BATCOUNT3) {
        wonLevel3 = 1;
    }

    if (BUTTON_PRESSED(BUTTON_R)) {
        playSoundB(click_data, click_length, 0);
        cheatOn = 1;
    }

    if (BUTTON_PRESSED(BUTTON_B) && cheatOn) {
        // if cheat is on then the ghost can shoot four knives in all directions at once
        throwKnives(1);
        throwKnives(2);
        throwKnives(3);
        throwKnives(4);
    }

    //can only throw candy if you have candy
    if (candyCount >= 1) {
        if (BUTTON_PRESSED(BUTTON_A)) {
            throwCandy(ghost.facePos);
        }
    }

    movePlayer(collisionmap3);
}

void initBats3() {
    for (int i = 0; i < BATCOUNT3; i++) {
        bats3[i].rdel = 1;
        bats3[i].cdel = 1;
        bats3[i].width = 16;
        bats3[i].height = 16;
        bats3[i].checkCollision = 1;
        bats3[i].hide = 0;
        bats3[i].candyTimer = 0;
        bats3[i].aniCounter = 0;
        bats3[i].curFrame = 0;
        bats3[i].numFrames = 2;
    }

    // manually placed where each bat is "captured" by the witches
    bats3[0].worldCol = 34;
    bats3[0].worldRow = 70;
    bats3[0].facePos = 1; // 1 for up, 2 for down, 3 for left, 4 for right

    bats3[1].worldCol = 108;
    bats3[1].worldRow = 32;
    bats3[1].facePos = 3;

    bats3[2].worldCol = 115;
    bats3[2].worldRow = 195;
    bats3[2].facePos = 4;

    bats3[3].worldCol = 280;
    bats3[3].worldRow = 220;
    bats3[3].facePos = 2;

    bats3[4].worldCol = 308;
    bats3[4].worldRow = 76;
    bats3[4].facePos = 3;

    bats3[5].worldCol = 377;
    bats3[5].worldRow = 15;
    bats3[5].facePos = 4;

    bats3[6].worldCol = 428;
    bats3[6].worldRow = 196;
    bats3[6].facePos = 3;

    bats3[7].worldCol = 430;
    bats3[7].worldRow = 15;
    bats3[7].facePos = 4;

    bats3[8].worldCol = 477;
    bats3[8].worldRow = 63;
    bats3[8].facePos = 1;

    bats3[9].worldCol = 486;
    bats3[9].worldRow = 230;
    bats3[9].facePos = 2;
}

void drawBats3() {
    for (int i = 0; i < BATCOUNT3; i++) {
        if (bats3[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (bats3[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (bats3[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((bats3[i].facePos - 1) * 2) + 8, (bats3[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateBats3(BATS* bats) {

    // starts timer when there's a collision so that batBuddies is incremented only once
    if (bats->candyTimer > 0) {
        bats->candyTimer--;
    }
    if (bats->hide == 0) {
        if (collision(bats->worldCol, bats->worldRow, bats->width, bats->height, ghost.worldCol, ghost.worldRow, ghost.width, ghost.height)) {
            if (bats->candyTimer == 0) {
                playSoundB(happyBat_data, happyBat_length, 0);
                bats->candyTimer = 50;
                bats->hide = 1;
                batBuddies++;
            }
        }
    }

    // keeps bats moving in place in their original position bc they're "hiding"
    if (bats->facePos == 1 || bats->facePos == 2) {
        moveBatsUpAndDown(bats, collisionmap3);
    } else {
        moveBatsSideToSide(bats, collisionmap3);
    }
}

// functions for candy that is found on the floor
void initCandyPlaced() {
    for (int i = 0; i < CANDYPLACEDCOUNT; i++) {
        candyPlaced[i].width = 16;
        candyPlaced[i].height = 16;
        candyPlaced[i].hide = 0;
        candyPlaced[i].aniCounter = 0;
        candyPlaced[i].curFrame = 0;
        candyPlaced[i].numFrames = 4;

        // randomize the candy positions on the map
        int newCol = rand() % 512;
        int newRow = rand() % 256;
        // checks all corners of candy for collison with map
        while (!((collisionmap3[OFFSET(newCol, newRow, MAPWIDTH)])
            && (collisionmap3[OFFSET(newCol + candyPlaced[i].width, newRow + candyPlaced[i].height, MAPWIDTH)])
            && (collisionmap3[OFFSET(newCol, newRow + candyPlaced[i].height, MAPWIDTH)]) 
            && (collisionmap3[OFFSET(newCol + candyPlaced[i].width, newRow, MAPWIDTH)]))) {
            newCol = rand() % 512;
            newRow = rand() % 256;
        }
        candyPlaced[i].worldCol = newCol;
        candyPlaced[i].worldRow = newRow;
    }
}

void updateCandyPlaced(ATTACKSPRITE* candyPlaced) {
    // timer that is used for collisions with ghost
    if (candyPlaced->timer2 > 0) {
        candyPlaced->timer2--;
    }

    // timer that is used for spawning more candy
    candyPlaced->timer++;
    if (candyPlaced->hide && candyPlaced->timer == 500) {
        candyPlaced->hide = 0;
        candyPlaced->timer = 0;

        // same logic as in init - also included it here to make candy placement more random
        int newCol = rand() % 512;
        int newRow = rand() % 256;
        while (!((collisionmap3[OFFSET(newCol, newRow, MAPWIDTH)]) && (collisionmap3[OFFSET(newCol + candyPlaced->height, newRow + candyPlaced->width, MAPWIDTH)]))) {
            newCol = rand() % 512;
            newRow = rand() % 256;
        }
        candyPlaced->worldCol = newCol;
        candyPlaced->worldRow = newRow;
    }

    // if collision with ghost then start spawining timer again and increment the amount of candy
    if (!candyPlaced->hide) {
        if (collision(candyPlaced->worldCol, candyPlaced->worldRow, candyPlaced->width, candyPlaced->height, ghost.worldCol, ghost.worldRow, ghost.width, ghost.height)) {
            if (candyPlaced->timer2 == 0) {
                playSoundB(gotCandySound_data, gotCandySound_length, 0);
                candyPlaced->timer2 = 50;
                candyPlaced->timer = 0;
                candyPlaced->hide = 1;
                candyCount++;
            }
        }
    }
}

void drawCandyPlaced() {
    for (int i = 0; i < CANDYPLACEDCOUNT; i++) {
        if (candyPlaced[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (candyPlaced[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (candyPlaced[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((candyPlaced[i].curFrame * 2) + 18, 4);
        }
        shadowOAMIndex++;
    }
}

void animateCandyPlaced() {
    for (int i = 0; i < CANDYPLACEDCOUNT; i++) {
        if (candyPlaced[i].aniCounter % 15 == 0) {
            candyPlaced[i].curFrame++;
            if (candyPlaced[i].curFrame == candyPlaced[i].numFrames) {
                candyPlaced[i].curFrame = 0;
            }
        }
        candyPlaced[i].aniCounter++;
    }
}

// functions for candy that ghost can shoot
void updateCandy3(ATTACKSPRITE* candy) {
    shoot(candy);

    // if a witch dies, restart the spawning timer
	if (candy->hide == 0) {
        for (int i = 0; i < WITCHCOUNT3; i++) {
            if (witches3[i].hide == 0) {
                if (collision(candy->worldCol, candy->worldRow, candy->width, candy->height, witches3[i].worldCol, witches3[i].worldRow, witches3[i].width, witches3[i].height)) {
                    playSoundB(witchScream_data, witchScream_length, 0);
                    witches3[i].hide = 1;
                    witches3[i].spawnTimer = 0;
                    candy->hide = 1;
                }
            }
        }
	}
}


void initWitches3() {
    for (int i = 0; i < WITCHCOUNT3; i++) {
        witches3[i].worldCol = 225;
        witches3[i].worldRow = 115;
        witches3[i].rdel = 1;
        witches3[i].cdel = 1;
        witches3[i].width = 16;
        witches3[i].height = 16;
        witches3[i].checkCollision = 1;
        witches3[i].movingPos = 3; //left 
        witches3[i].hide = 0;
        witches3[i].aniCounter = 0;
        witches3[i].curFrame = 0;
        witches3[i].numFrames = 2;
    }
}

void drawWitches3() {
    for (int i = 0; i < WITCHCOUNT3; i++) {
        if (witches3[i].hide == 1) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (witches3[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (witches3[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((witches3[i].movingPos - 1) * 2, (witches3[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateWitches3(WITCH* witch) {
    // spawn witch every 600 frames if they're inactive
    witch->spawnTimer++;
    if (witch->hide && witch->spawnTimer == 600) {
        witch->hide = 0;
        witch->spawnTimer = 0;
    }

    //if the ghost collides with the witch a ghost buddy dies or you die if you have no buddies
    if (witch->hide == 0) {
        if (collision(witch->worldCol, witch->worldRow, witch->width, witch->height, ghost.worldCol, ghost.worldRow, ghost.width, ghost.height)) {
            lostLevel3 = 1;
        }
    }

    moveWitch(witch, collisionmap3);

}

// for cheat only
void updateKnives3(ATTACKSPRITE* knife) {
    // timer for cheat and having the knives kill the witches
    if (knife->timer2 > 0) {
        knife->timer2--;
    }

    shoot(knife);

    // if the cheat is on then the knives can kill the witches
    if (cheatOn) {
        for (int i = 0; i < WITCHCOUNT3; i++) {
            if (witches3[i].hide == 0 && knife->hide == 0) {
                if (collision(knife->worldCol, knife->worldRow, knife->width, knife->height, witches3[i].worldCol, witches3[i].worldRow, witches3[i].width, witches3[i].height)) {
                    if (knife->timer2 == 0) {
                        playSoundB(witchScream_data, witchScream_length, 0);
                        knife->timer2 = 30;
                        knife->hide = 1;
                        witches3[i].hide = 1;
                        witches3[i].spawnTimer = 0;
                        witchesOut--;
                    }
                }
            }
        }
    }
}

void drawScore3() {
    // for bat count
    //first digit
    shadowOAM[shadowOAMIndex].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = 83 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_TILEID(((batBuddies % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 1].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 1].attr1 = 97 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 1].attr2 = ATTR2_TILEID((batBuddies % 10) * 2 , 8);

    //for candy
    //first digit
    shadowOAM[shadowOAMIndex + 2].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 2].attr1 = 210 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 2].attr2 = ATTR2_TILEID(((candyCount % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 3].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 3].attr1 = 224 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 3].attr2 = ATTR2_TILEID((candyCount % 10) * 2 , 8);

    shadowOAMIndex++;
}



// level 3 insructions
// you did it! you can have your party now!
// ... but wait, where are your bat buddies? :(
// the witches have taken them and their candy! you have to go back and help them!
// you'll have to sneak through the forest to find them. luckily there's still some candy left behind from the trick-or-treaters that
// you can use to defeat the witches. but be careful not to get caught, the witches are very angry now and will take you to your grave if you get caught! good luck!
// so just all your witch functions like normal
// maually place candy around the map in a long init candy function (just draw and init?)
// manually place bats as well, they can be in place for now because you can add animation to them later?