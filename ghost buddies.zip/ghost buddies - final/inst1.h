
//{{BLOCK(inst1)

//======================================================================
//
//	inst1, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 374 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 11968 + 2048 = 14528
//
//	Time-stamp: 2021-12-14, 16:41:53
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INST1_H
#define GRIT_INST1_H

#define inst1TilesLen 11968
extern const unsigned short inst1Tiles[5984];

#define inst1MapLen 2048
extern const unsigned short inst1Map[1024];

#define inst1PalLen 512
extern const unsigned short inst1Pal[256];

#endif // GRIT_INST1_H

//}}BLOCK(inst1)
