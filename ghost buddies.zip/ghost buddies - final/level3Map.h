
//{{BLOCK(level3Map)

//======================================================================
//
//	level3Map, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 770 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 24640 + 4096 = 29248
//
//	Time-stamp: 2021-12-13, 01:11:42
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL3MAP_H
#define GRIT_LEVEL3MAP_H

#define level3MapTilesLen 24640
extern const unsigned short level3MapTiles[12320];

#define level3MapMapLen 4096
extern const unsigned short level3MapMap[2048];

#define level3MapPalLen 512
extern const unsigned short level3MapPal[256];

#endif // GRIT_LEVEL3MAP_H

//}}BLOCK(level3Map)
