
//{{BLOCK(collisionmap3)

//======================================================================
//
//	collisionmap3, 512x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 131072 = 131584
//
//	Time-stamp: 2021-12-13, 01:11:28
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP3_H
#define GRIT_COLLISIONMAP3_H

#define collisionmap3BitmapLen 131072
extern const unsigned short collisionmap3Bitmap[65536];

#define collisionmap3PalLen 512
extern const unsigned short collisionmap3Pal[256];

#endif // GRIT_COLLISIONMAP3_H

//}}BLOCK(collisionmap3)
