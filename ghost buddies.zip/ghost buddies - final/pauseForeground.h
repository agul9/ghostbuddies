
//{{BLOCK(pauseForeground)

//======================================================================
//
//	pauseForeground, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 9 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 288 + 2048 = 2848
//
//	Time-stamp: 2021-12-14, 15:33:37
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSEFOREGROUND_H
#define GRIT_PAUSEFOREGROUND_H

#define pauseForegroundTilesLen 288
extern const unsigned short pauseForegroundTiles[144];

#define pauseForegroundMapLen 2048
extern const unsigned short pauseForegroundMap[1024];

#define pauseForegroundPalLen 512
extern const unsigned short pauseForegroundPal[256];

#endif // GRIT_PAUSEFOREGROUND_H

//}}BLOCK(pauseForeground)
