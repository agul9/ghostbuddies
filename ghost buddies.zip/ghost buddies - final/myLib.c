#include "myLib.h"

// The start of the video memory
unsigned volatile short *videoBuffer = (unsigned short *)0x6000000;

// The start of DMA registers
DMA *dma = (DMA *)0x40000B0;

// Set a pixel on the screen in Mode 3
void setPixel3(int col, int row, unsigned short color)
{

    videoBuffer[OFFSET(col, row, SCREENWIDTH)] = color;
}

// Set a pixel on the screen in Mode 4
void setPixel4(int col, int row, unsigned char colorIndex)
{
    volatile unsigned short pixelData = videoBuffer[OFFSET(col, row, SCREENWIDTH) / 2];
    if (col & 1)
    {
        pixelData &= 0x00FF;
        pixelData |= colorIndex << 8;
    }
    else
    {
        pixelData &= 0xFF00;
        pixelData |= colorIndex;
    }
    videoBuffer[OFFSET(col, row, SCREENWIDTH) / 2] = pixelData;
}

// Draw a rectangle at the specified location and size in Mode 3
void drawRect3(int col, int row, int width, int height, volatile unsigned short color)
{

    for (int r = 0; r < height; r++)
    {
        DMANow(3, &color, &videoBuffer[OFFSET(col, row + r, SCREENWIDTH)], DMA_SOURCE_FIXED | width);
    }
}

// Draw a rectangle at the specified location and size in Mode 4
void drawRect4(int col, int row, int width, int height, volatile unsigned char colorIndex)
{
    volatile unsigned short pixelData = colorIndex | (colorIndex << 8);
    for (int r = 0; r < height; r++)
    {
        // Ensure we don't DMA 0 copies
        if (width == 1)
            setPixel4(col, row + r, colorIndex);
        else if (width == 2)
        {
            setPixel4(col, row + r, colorIndex);
            setPixel4(col + 1, row + r, colorIndex);
        }
        else if ((col & 1) && (width & 1)) // Odd width odd col
        {
            setPixel4(col, row + r, colorIndex);
            DMANow(3, &pixelData, &videoBuffer[OFFSET(col + 1, row + r, SCREENWIDTH) / 2], DMA_SOURCE_FIXED | (width - 1) / 2);
        }
        else if (width & 1) // Even col odd width
        {
            DMANow(3, &pixelData, &videoBuffer[OFFSET(col, row + r, SCREENWIDTH) / 2], DMA_SOURCE_FIXED | (width - 1) / 2);
            setPixel4(col + width - 1, row + r, colorIndex);
        }
        else if (col & 1) // Odd col even width
        {
            setPixel4(col, row + r, colorIndex);
            DMANow(3, &pixelData, &videoBuffer[OFFSET(col + 1, row + r, SCREENWIDTH) / 2], DMA_SOURCE_FIXED | (width - 2) / 2);
            setPixel4(col + width - 1, row + r, colorIndex);
        }
        else // Even col even width
        {
            DMANow(3, &pixelData, &videoBuffer[OFFSET(col, row + r, SCREENWIDTH) / 2], DMA_SOURCE_FIXED | width / 2);
        }
    }
}

// Fill the entire screen with a single color in Mode 3
void fillScreen3(volatile unsigned short color)
{
    unsigned short c = color;
    DMANow(3, &c, videoBuffer, DMA_SOURCE_FIXED | (SCREENWIDTH * SCREENHEIGHT));
}

// Fill the entire screen with a single color in Mode 4
void fillScreen4(volatile unsigned char colorIndex)
{
    volatile unsigned short pixelData = colorIndex | (colorIndex << 8);
    DMANow(3, &pixelData, videoBuffer, DMA_SOURCE_FIXED | (SCREENWIDTH * SCREENHEIGHT) / 2);
}

// Draw an image at the specified location and size in Mode 3
void drawImage3(int col, int row, int width, int height, const unsigned short *image)
{
    for (int r = 0; r < height; r++)
    {
        if (row + r < 0) continue;
        DMANow(3, &image[OFFSET(0, r, width)], &videoBuffer[OFFSET(col, row + r, SCREENWIDTH)], width);
    }
}

// Draw an image at the specified location and size in Mode 4 (must be even col and width)
void drawImage4(int col, int row, int width, int height, const unsigned short *image)
{
    for (int i = 0; i < height; i++)
    {
        if (row + i < 0) continue;
        DMANow(3, &image[OFFSET(0, i, width / 2)], &videoBuffer[OFFSET(col, row + i, SCREENWIDTH) / 2], width / 2);
    }
}

// Fill the entire screen with an image in Mode 3
void drawFullscreenImage3(const unsigned short *image)
{

    DMANow(3, image, videoBuffer, SCREENWIDTH * SCREENHEIGHT);
}

// Fill the entire screen with an image in Mode 4
void drawFullscreenImage4(const unsigned short *image)
{
    DMANow(3, image, videoBuffer, SCREENWIDTH * SCREENHEIGHT / 2);
}

// Pause code execution until vertical blank begins
void waitForVBlank()
{
    while (SCANLINECOUNTER > 160)
        ;
    while (SCANLINECOUNTER < 160)
        ;
}

// Flips the page
void flipPage()
{

    if (REG_DISPCTL & DISP_BACKBUFFER)
    {
        videoBuffer = BACKBUFFER;
    }
    else
    {
        videoBuffer = FRONTBUFFER;
    }
    REG_DISPCTL ^= DISP_BACKBUFFER;
}

// Set up and begin a DMA transfer
void DMANow(int channel, volatile const void *src, volatile void *dst, unsigned int cnt)
{
    // Turn DMA off
    dma[channel].cnt = 0;

    // Set source and destination
    dma[channel].src = src;
    dma[channel].dst = dst;

    // Set control and begin
    dma[channel].cnt = cnt | DMA_ON;
}

// Return true if the two rectangular areas are overlapping
int collision(int colA, int rowA, int widthA, int heightA, int colB, int rowB, int widthB, int heightB)
{
    return rowA < rowB + heightB - 1 && rowA + heightA - 1 > rowB && colA < colB + widthB - 1 && colA + widthA - 1 > colB;
}

// Hides all sprites in the shadowOAM; Must DMA the shadowOAM into the OAM after calling this function
void hideSprites()
{
    for (int i = 0; i < 128; i++)
    {
        shadowOAM[i].attr0 = ATTR0_HIDE;
    }
}

// ============================== FUNCTIONS AND VARIABLES RELATED TO ALL LEVELS ===============================

// Initialize the player
void initPlayer(int col, int row) {
    ghost.width = 16;
    ghost.height = 16;
    ghost.rdel = 1;
    ghost.cdel = 1;
    ghost.worldCol = col;
    ghost.worldRow = row;
    ghost.facePos = 2;
    ghost.aniCounter = 0;
    ghost.curFrame = 0;
    ghost.numFrames = 2;
    ghost.hide = 0;
}

void movePlayer(unsigned char* collisionMap) {
    // complex camera movement
    // collision map
    if(BUTTON_HELD(BUTTON_UP)) {
        /*make sure ghost doesn't go off the map here, check collision map*/
        if (ghost.worldRow > 0 &&
                ((collisionMap[OFFSET(ghost.worldCol, ghost.worldRow - ghost.rdel, MAPWIDTH)]) &&
                    (collisionMap[OFFSET(ghost.worldCol + ghost.width - 1, ghost.worldRow - ghost.rdel, MAPWIDTH)]))) {
            // Update ghost's world position if the above is true
            ghost.worldRow -= ghost.rdel;
            ghost.facePos = 1;

            /*make sure the background offset doesn't show past the edge, and only update the offset variables if ghost is in the right spot*/
            if (vOff > 0 && ((ghost.worldRow - vOff) < (SCREENHEIGHT / 2))) {
                // Update background offset variable if the above is true
                vOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_DOWN)) {
        if (ghost.worldRow < (MAPHEIGHT - ghost.height) &&
                ((collisionMap[OFFSET(ghost.worldCol, ghost.worldRow + (ghost.height - 1) + ghost.rdel, MAPWIDTH)]) &&
                    (collisionMap[OFFSET(ghost.worldCol + ghost.width - 1, ghost.worldRow + (ghost.height - 1) + ghost.rdel, MAPWIDTH)]))) {
            // Update ghost's world position if the above is true
            ghost.worldRow += ghost.rdel;
            ghost.facePos = 2;

            if (vOff < (MAPHEIGHT - SCREENHEIGHT) && ((ghost.worldRow - vOff) > (SCREENHEIGHT / 2))) {
                // Update background offset variable if the above is true
                vOff++;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_LEFT)) {
        if (ghost.worldCol > 0 &&
                ((collisionMap[OFFSET(ghost.worldCol - ghost.cdel, ghost.worldRow, MAPWIDTH)]) &&
                    (collisionMap[OFFSET(ghost.worldCol - ghost.cdel, ghost.worldRow + ghost.height - 1, MAPWIDTH)]))) {
            // Update ghost's world position if the above is true
            ghost.worldCol -= ghost.cdel;
            ghost.facePos = 3;

            if (hOff > 0 && ((ghost.worldCol - hOff) < (SCREENWIDTH / 2))) {
                // Update background offset variable if the above is true
                hOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (ghost.worldCol < (MAPWIDTH - ghost.width) &&
                 ((collisionMap[OFFSET(ghost.worldCol + (ghost.width - 1) + ghost.cdel, ghost.worldRow, MAPWIDTH)]) &&
                    (collisionMap[OFFSET(ghost.worldCol + (ghost.width - 1) + ghost.cdel, ghost.worldRow + ghost.height - 1, MAPWIDTH)]))) {
            // Update ghost's world position if the above is true
            ghost.worldCol += ghost.cdel;
            ghost.facePos = 4;

            if (hOff < (MAPWIDTH - SCREENWIDTH) && ((ghost.worldCol - hOff) > (SCREENWIDTH / 2))) {
                // Update background offset variable if the above is true
                hOff++;
            }
        }
    }
}

void animatePlayer() {
    if(ghost.aniCounter % 20 == 0) {
        ghost.curFrame++;
        if (ghost.curFrame == ghost.numFrames) {
            ghost.curFrame = 0;
        }
    }
    ghost.aniCounter++;
}

// Draw the player
void drawPlayer() { 
    if (ghost.hide) {
        shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (ghost.worldRow - vOff)) | ATTR0_SQUARE;
        shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (ghost.worldCol - hOff)) | ATTR1_SMALL;
        shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((ghost.facePos - 1) * 2, ghost.curFrame * 2);
        //shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(0, 0);
    }
    shadowOAMIndex++;
}

void initAttackSprites() {
    for (int i = 0; i < KNIVESCOUNT; i++) {
        knives[i].worldRow = ghost.worldRow;
        knives[i].worldCol = ghost.worldCol;
        knives[i].cdel = 2;
        knives[i].rdel = 2;
        knives[i].width = 16;
        knives[i].height = 16;
        knives[i].hide = 1;
    }
    for (int i = 0; i < 20; i++) {
        candy[i].worldRow = ghost.worldRow;
        candy[i].worldCol = ghost.worldCol;
        candy[i].cdel = 2;
        candy[i].rdel = 2;
        candy[i].width = 16;
        candy[i].height = 16;
        candy[i].hide = 1;
    }
}

// keeps whatever object is shot moving
void shoot(ATTACKSPRITE* attackObj) {
    // this wil change based on animation later
    // 1 for up, 2 for down, 3 for left, 4 for right

    if (attackObj->hide == 0) {
        if (attackObj->movingPos == 1) { // if object is thrown up
            if (attackObj->worldRow - 1 >= 0) {
                attackObj->worldRow -= attackObj->rdel;
            } else {
		        attackObj->hide = 1;
	        }
        }
        if (attackObj->movingPos == 2) { //if object is thrown down
            if (attackObj->worldRow + candy->height + 1 <= SCREENHEIGHT + vOff) {
                attackObj->worldRow += attackObj->rdel;
            } else {
		        attackObj->hide = 1;
	        }
        }
        if (attackObj->movingPos == 3) { //if object is thrown left
            if (attackObj->worldCol - 1 >= 0) {
                attackObj->worldCol -= attackObj->cdel;
            } else {
		        attackObj->hide = 1;
	        }
        }
        if (attackObj->movingPos == 4) { //if object is thrown right
            if (attackObj->worldCol + attackObj->width + 1 <= SCREENWIDTH + hOff) {
                attackObj->worldCol += attackObj->cdel;
            } else {
		        attackObj->hide = 1;
	        }
        }
    }
}

void drawKnives() {
    for (int i = 0; i < KNIVESCOUNT; i++) {
        if (knives[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (knives[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (knives[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(30, ((knives[i].movingPos - 1) * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

// goes through the pool and initializes first inactive one
void throwKnives(int movingPos) {
	for (int i = 0; i < KNIVESCOUNT; i++) {
		if (knives[i].hide == 1) {
			knives[i].worldRow = ghost.worldRow;
			knives[i].worldCol = ghost.worldCol;
			knives[i].hide = 0;
            knives[i].movingPos = movingPos;
			break;
		}
	}
}

void moveBats(BATS * bats, unsigned char * collisionMap) {
    //keep bats moving along the path
    // 1 for up, 2 for down, 3 for left, 4 for right

    // check if the bat can keep moving
    if (bats->facePos == 1 && !(collisionMap[OFFSET(bats->worldCol, bats->worldRow - 1, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    if (bats->facePos == 2 && !(collisionMap[OFFSET(bats->worldCol, bats->worldRow + bats->height, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow + bats->height, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    if (bats->facePos == 3 && !(collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow + bats->height - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    if (bats->facePos == 4 && !(collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow + bats->height - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    
    // if bat can't keep moving or "hits a wall", generate a new position to keep moving
    while (bats->checkCollision) {
        bats->facePos = rand() % 4 + 1;
        if (bats->facePos == 1 && collisionMap[OFFSET(bats->worldCol, bats->worldRow - 1, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow - 1, MAPWIDTH)]) {
                bats->facePos = 1;
                bats->checkCollision = 0;
                bats->rdel = -1;
                bats->cdel = 0;
        }

        if (bats->facePos == 2 && collisionMap[OFFSET(bats->worldCol, bats->worldRow + bats->height, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow + bats->height, MAPWIDTH)]) {
                bats->facePos = 2;
                bats->checkCollision = 0;
                bats->rdel = 1;
                bats->cdel = 0;
        }

        if (bats->facePos == 3 && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow + bats->height - 1, MAPWIDTH)]) {
                bats->facePos = 3;
                bats->checkCollision = 0;
                bats->rdel = 0;
                bats->cdel = -1;
        }
        
        if (bats->facePos == 4 && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow + bats->height - 1, MAPWIDTH)]) {
                bats->facePos = 4;
                bats->checkCollision = 0;
                bats->rdel = 0;
                bats->cdel = 1;
        }
    }

    bats->worldRow += bats->rdel;
    bats->worldCol += bats->cdel;
}

void animateBats(BATS * bats) {
    if(bats->aniCounter % 20 == 0) {
        bats->curFrame++;
        if (bats->curFrame == bats->numFrames) {
            bats->curFrame = 0;
        }
    }
    bats->aniCounter++;
}

void moveBatsUpAndDown(BATS * bats, unsigned char * collisionMap) {
    // same code as moveBats, just with the up and down positions
    if (bats->facePos == 1 && !(collisionMap[OFFSET(bats->worldCol, bats->worldRow - 1, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    if (bats->facePos == 2 && !(collisionMap[OFFSET(bats->worldCol, bats->worldRow + bats->height, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow + bats->height, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    while (bats->checkCollision) {
        bats->facePos = rand() % 4 + 1;
        if (bats->facePos == 1 && collisionMap[OFFSET(bats->worldCol, bats->worldRow - 1, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow - 1, MAPWIDTH)]) {
                bats->facePos = 1;
                bats->checkCollision = 0;
                bats->rdel = -1;
                bats->cdel = 0;
        }

        if (bats->facePos == 2 && collisionMap[OFFSET(bats->worldCol, bats->worldRow + bats->height, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width - 1, bats->worldRow + bats->height, MAPWIDTH)]) {
                bats->facePos = 2;
                bats->checkCollision = 0;
                bats->rdel = 1;
                bats->cdel = 0;
        }
    }
    bats->worldRow += bats->rdel;
    bats->worldCol += bats->cdel;
}

void moveBatsSideToSide(BATS * bats, unsigned char * collisionMap) {
    // same code as moveBats except just with left and right positions
    if (bats->facePos == 3 && !(collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow + bats->height - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    if (bats->facePos == 4 && !(collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow + bats->height - 1, MAPWIDTH)])) {
            bats->checkCollision = 1;
    }
    while (bats->checkCollision) {
        bats->facePos = rand() % 4 + 3;
        if (bats->facePos == 3 && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol - 1, bats->worldRow + bats->height - 1, MAPWIDTH)]) {
                bats->facePos = 3;
                bats->checkCollision = 0;
                bats->rdel = 0;
                bats->cdel = -1;
        }
        
        if (bats->facePos == 4 && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(bats->worldCol + bats->width, bats->worldRow + bats->height - 1, MAPWIDTH)]) {
                bats->facePos = 4;
                bats->checkCollision = 0;
                bats->rdel = 0;
                bats->cdel = 1;
        }
    }
    bats->worldRow += bats->rdel;
    bats->worldCol += bats->cdel;
}

void drawCandy() {
    for (int i = 0; i < 20; i++) {
        if (candy[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (candy[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (candy[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(18, 4);
        }
        shadowOAMIndex++;
    }
}

// goes through the pool and initializes first inactive one
void throwCandy(int movingPos) {
	for (int i = 0; i < 20; i++) {
		if (candy[i].hide == 1) {
			candy[i].worldRow = ghost.worldRow;
			candy[i].worldCol = ghost.worldCol;
			candy[i].hide = 0;
            candy[i].movingPos = movingPos;
            candyCount--;
			break;
		}
	}
}

void moveWitch(WITCH * witch, unsigned char * collisionMap) {
    // keep witch moving along path
    // 1 for up, 2 for down, 3 for left, 4 for right
    // same code as moveBats

    if (witch->movingPos == 1 && !(collisionMap[OFFSET(witch->worldCol, witch->worldRow - 1, MAPWIDTH)]
        && collisionMap[OFFSET(witch->worldCol + witch->width - 1, witch->worldRow - 1, MAPWIDTH)])) {
            witch->checkCollision = 1;
    }
    if (witch->movingPos == 2 && !(collisionMap[OFFSET(witch->worldCol, witch->worldRow + witch->height, MAPWIDTH)]
        && collisionMap[OFFSET(witch->worldCol + witch->width - 1, witch->worldRow + witch->height, MAPWIDTH)])) {
            witch->checkCollision = 1;
    }
    if (witch->movingPos == 3 && !(collisionMap[OFFSET(witch->worldCol - 1, witch->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(witch->worldCol - 1, witch->worldRow + witch->height - 1, MAPWIDTH)])) {
            witch->checkCollision = 1;
    }
    if (witch->movingPos == 4 && !(collisionMap[OFFSET(witch->worldCol + witch->width, witch->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(witch->worldCol + witch->width, witch->worldRow + witch->height - 1, MAPWIDTH)])) {
            witch->checkCollision = 1;
    }
    
    while (witch->checkCollision) {
        witch->movingPos = rand() % 4 + 1;
        if (witch->movingPos == 1 && collisionMap[OFFSET(witch->worldCol, witch->worldRow - 1, MAPWIDTH)]
            && collisionMap[OFFSET(witch->worldCol + witch->width - 1, witch->worldRow - 1, MAPWIDTH)]) {
                witch->movingPos = 1;
                witch->checkCollision = 0;
                witch->rdel = -1;
                witch->cdel = 0;
        }

        if (witch->movingPos == 2 && collisionMap[OFFSET(witch->worldCol, witch->worldRow + witch->height, MAPWIDTH)]
            && collisionMap[OFFSET(witch->worldCol + witch->width - 1, witch->worldRow + witch->height, MAPWIDTH)]) {
                witch->movingPos = 2;
                witch->checkCollision = 0;
                witch->rdel = 1;
                witch->cdel = 0;
        }

        if (witch->movingPos == 3 && collisionMap[OFFSET(witch->worldCol - 1, witch->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(witch->worldCol - 1, witch->worldRow + witch->height - 1, MAPWIDTH)]) {
                witch->movingPos = 3;
                witch->checkCollision = 0;
                witch->rdel = 0;
                witch->cdel = -1;
        }
        
        if (witch->movingPos == 4 && collisionMap[OFFSET(witch->worldCol + witch->width, witch->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(witch->worldCol + witch->width, witch->worldRow + witch->height - 1, MAPWIDTH)]) {
                witch->movingPos = 4;
                witch->checkCollision = 0;
                witch->rdel = 0;
                witch->cdel = 1;
        }
    }

    witch->worldRow += witch->rdel;
    witch->worldCol += witch->cdel;
}

void animateWitches(WITCH * witch) {
    if(witch->aniCounter % 20 == 0) {
        witch->curFrame++;
        if (witch->curFrame == witch->numFrames) {
            witch->curFrame = 0;
        }
    }
    witch->aniCounter++;
}

void moveAnimals(ANIMALS * animals, unsigned char * collisionMap) {
    // same code as moveBats
    if (animals->movingPos == 1 && !(collisionMap[OFFSET(animals->worldCol, animals->worldRow - 1, MAPWIDTH)]
        && collisionMap[OFFSET(animals->worldCol + animals->width - 1, animals->worldRow - 1, MAPWIDTH)])) {
            animals->checkCollision = 1;
    }
    if (animals->movingPos == 2 && !(collisionMap[OFFSET(animals->worldCol, animals->worldRow + animals->height, MAPWIDTH)]
        && collisionMap[OFFSET(animals->worldCol + animals->width - 1, animals->worldRow + animals->height, MAPWIDTH)])) {
            animals->checkCollision = 1;
    }
    if (animals->movingPos == 3 && !(collisionMap[OFFSET(animals->worldCol - 1, animals->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(animals->worldCol - 1, animals->worldRow + animals->height - 1, MAPWIDTH)])) {
            animals->checkCollision = 1;
    }
    if (animals->movingPos == 4 && !(collisionMap[OFFSET(animals->worldCol + animals->width, animals->worldRow, MAPWIDTH)]
        && collisionMap[OFFSET(animals->worldCol + animals->width, animals->worldRow + animals->height - 1, MAPWIDTH)])) {
            animals->checkCollision = 1;
    }
    
    while (animals->checkCollision) {
        animals->movingPos = rand() % 4 + 1;
        if (animals->movingPos == 1 && collisionMap[OFFSET(animals->worldCol, animals->worldRow - 1, MAPWIDTH)]
            && collisionMap[OFFSET(animals->worldCol + animals->width - 1, animals->worldRow - 1, MAPWIDTH)]) {
                animals->movingPos = 1;
                animals->checkCollision = 0;
                animals->rdel = -1;
                animals->cdel = 0;
        }

        if (animals->movingPos == 2 && collisionMap[OFFSET(animals->worldCol, animals->worldRow + animals->height, MAPWIDTH)]
            && collisionMap[OFFSET(animals->worldCol + animals->width - 1, animals->worldRow + animals->height, MAPWIDTH)]) {
                animals->movingPos = 2;
                animals->checkCollision = 0;
                animals->rdel = 1;
                animals->cdel = 0;
        }

        if (animals->movingPos == 3 && collisionMap[OFFSET(animals->worldCol - 1, animals->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(animals->worldCol - 1, animals->worldRow + animals->height - 1, MAPWIDTH)]) {
                animals->movingPos = 3;
                animals->checkCollision = 0;
                animals->rdel = 0;
                animals->cdel = -1;
        }
        
        if (animals->movingPos == 4 && collisionMap[OFFSET(animals->worldCol + animals->width, animals->worldRow, MAPWIDTH)]
            && collisionMap[OFFSET(animals->worldCol + animals->width, animals->worldRow + animals->height - 1, MAPWIDTH)]) {
                animals->movingPos = 4;
                animals->checkCollision = 0;
                animals->rdel = 0;
                animals->cdel = 1;
        }
    }
    animals->worldRow += animals->rdel;
    animals->worldCol += animals->cdel;
}

void animateAnimals(ANIMALS* animal) {
    if (animal->aniCounter % 20 == 0) {
        animal->curFrame++;
        if (animal->curFrame == animal->numFrames) {
            animal->curFrame = 0;
        }
    }
    animal->aniCounter++;
}
