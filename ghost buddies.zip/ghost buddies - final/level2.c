#include "myLib.h"
#include "level2.h"
#include "collisionmap2.h"

#include "sound.h"
#include "happyBat.h"
#include "killSound.h"
#include "witchScream.h"
#include "witchLaugh.h"
#include "click.h"

// Variables
int hOff;
int vOff;
int cheatOn;
int candyCount;
int ghostBuddies;
int witchesOut;
int lostLevel2; // set to 1 when witch collides with ghost, and ghost buddies == 0
int wonLevel2; // set to 1 when you get 10 ghost buddies

OBJ_ATTR shadowOAM[128];
int shadowOAMIndex;

// from lib.h in all levels
ANISPRITE ghost;
ATTACKSPRITE knives[KNIVESCOUNT];
ATTACKSPRITE candy[20];

// from level2.h specific to level 2
WITCH witches2[WITCHCOUNT2];
ANIMALS animals2[ANIMALCOUNT2];
BATS bats2[BATCOUNT2];

unsigned char* collisionmap2 = collisionmap2Bitmap;

SOUND soundA;
SOUND soundB;

// Initialize the game
void initLevel2() {
    vOff = 96;
    hOff = 9;

    candyCount = 0;
    ghostBuddies = 0;
    wonLevel2 = 0;
    lostLevel2 = 0;
    witchesOut = WITCHCOUNT2;
    cheatOn = 0;

    initPlayer(83, 159);
    initAttackSprites();
    initWitches2();
    initBats2();
    initAnimals2();
}

// Updates the game each frame
void updateLevel2() {

	updatePlayer2();
    animatePlayer();

    for (int i = 0; i < BATCOUNT2; i++) {
        updateBats2(&bats2[i]);
        animateBats(&bats2[i]);
    }
    for (int i = 0; i < KNIVESCOUNT; i++) {
        updateKnives2(&knives[i]);
    }
    for (int i = 0; i < 20; i++) {
        updateCandy2(&candy[i]);
    }
    for (int i = 0; i < WITCHCOUNT2; i++) {
        updateWitches2(&witches2[i]);
        animateWitches(&witches2[i]);
    }
    for (int i = 0; i < ANIMALCOUNT2; i++) {
        updateAnimals2(&animals2[i]);
        animateAnimals(&animals2[i]);
    }
}

// Draws the game each frame
void drawLevel2() {
    shadowOAMIndex = 0; 

    drawPlayer();
    drawWitches2();
    drawKnives();
    drawCandy();
    drawBats2();
    drawAnimals2();
    drawScore2();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG1HOFF = hOff;
    REG_BG1VOFF = vOff;
}

// Handle every-frame actions of the player
void updatePlayer2() {
    if (ghostBuddies == 10) {
        wonLevel2 = 1;
    }

    if (BUTTON_PRESSED(BUTTON_R)) {
        playSoundB(click_data, click_length, 0);
        cheatOn = 1;
    }

    if (BUTTON_PRESSED(BUTTON_B)) {
        // if cheat is on then the ghost can shoot four knives in all directions at once
        if (cheatOn) {
            throwKnives(1);
            throwKnives(2);
            throwKnives(3);
            throwKnives(4);
        } else {
            throwKnives(ghost.facePos);
        }
    }

    //can only throw candy if you have candy
    if (candyCount >= 1) {
        if (BUTTON_PRESSED(BUTTON_A)) {
            throwCandy(ghost.facePos);
        }
    }

    movePlayer(collisionmap2);
}

void initBats2() {
    int j = 10;
    int k = 5;
    for (int i = 0; i < BATCOUNT2; i++) {
        bats2[i].worldCol = 40 + k;
        bats2[i].worldRow = 30 + j;
        bats2[i].rdel = 1;
        bats2[i].cdel = 1;
        bats2[i].width = 16;
        bats2[i].height = 16;
        bats2[i].facePos = 1; // 1 for up, 2 for down, 3 for left, 4 for right
        bats2[i].checkCollision = 1;
        bats2[i].hide = 0;
        bats2[i].candyTimer = 0;
        bats2[i].foundBat = 0;
        bats2[i].aniCounter = 0;
        bats2[i].curFrame = 0;
        bats2[i].numFrames = 2;
        j += 10;
        k +=5;
    }
}

void drawBats2() {
    for (int i = 0; i < BATCOUNT2; i++) {
        if (bats2[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (bats2[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (bats2[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((bats2[i].facePos - 1) * 2) + 8, (bats2[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateBats2(BATS* bats) {
    //if you run into a bats, you get candy, the bats disappears, and the timer starts again to determine when to spawn another bats
    if (bats->hide == 0) {
        if (collision(ghost.worldCol, ghost.worldRow, ghost.width, ghost.height, bats->worldCol, bats->worldRow, bats->width, bats->height)) {
            if (bats->candyTimer == 0) {
                playSoundB(happyBat_data, happyBat_length, 0);
                candyCount++;
                bats->hide = 1;
                bats->candyTimer = 30;
                bats->spawnTimer = 0;
                bats->foundBat = 1;
            }
        }
    }

    if (bats->foundBat) { // once you find the bats and get candy and start killing the witches, the bats "come out" like normal instead of hiding
        bats->spawnTimer++;
        // spawn a new bats every 600 frames
        if (bats->hide && bats->spawnTimer == 600) {
            bats->hide = 0;
            bats->spawnTimer = 0;

            // spawn bats at a random location
            int newCol = rand() % 512;
            int newRow = rand() % 256;
            while (!((collisionmap2[OFFSET(newCol, newRow, MAPWIDTH)]) && (collisionmap2[OFFSET(newCol + bats->height, newRow + bats->width, MAPWIDTH)]))) {
                newCol = rand() % 512;
                newRow = rand() % 256;
            }
            bats->worldCol = newCol;
            bats->worldRow = newRow;
        }

        // candy timer used to make sure candyCount doesn't keep incrementing upon collision with ghost
        if (bats->candyTimer > 0) {
            bats->candyTimer--;
        }

        moveBats(bats, collisionmap2);

    } else { // only move up and down if they haven't been found yet so that they're confined in one area bc they're "hiding"
        moveBatsUpAndDown(bats, collisionmap2);
    }
}

void updateKnives2(ATTACKSPRITE* knife) {
    // timer for collision bt knife and animals
    if (knife->timer > 0) {
        knife->timer--;
    }
    
    // timer for cheat and having the knives kill the witches
    if (knife->timer2 > 0) {
        knife->timer2--;
    }

    shoot(knife);

    // if knife collides with an animal then start the collision timer and reset the spawning timer for the animals
    for (int i = 0; i < ANIMALCOUNT2; i++) {
        if (animals2[i].hide == 0 && knife->hide == 0) {
            if (collision(knife->worldCol, knife->worldRow, knife->width, knife->height, animals2[i].worldCol, animals2[i].worldRow, animals2[i].width, animals2[i].height)) {
                if (knife->timer == 0) {
                    playSoundB(killSound_data, killSound_length, 0);
                    knife->timer = 30;
                    knife->hide = 1;
                    animals2[i].hide = 1;
                    animals2[i].spawnTimer = 0;
                    ghostBuddies++;
                }
            }
        }
    }

    // if the cheat is on then the knives can kill the witches
    if (cheatOn) {
        for (int i = 0; i < WITCHCOUNT2; i++) {
            if (witches2[i].hide == 0 && knife->hide == 0) {
                if (collision(knife->worldCol, knife->worldRow, knife->width, knife->height, witches2[i].worldCol, witches2[i].worldRow, witches2[i].width, witches2[i].height)) {
                    if (knife->timer2 == 0) {
                        playSoundB(witchScream_data, witchScream_length, 0);
                        knife->timer2 = 30;
                        knife->hide = 1;
                        witches2[i].hide = 1;
                        witches2[i].spawnTimer = 0;
                        witchesOut--;
                    }
                }
            }
        }
    }
}

void updateCandy2(ATTACKSPRITE* candy) {
    shoot(candy);

    // if a witch dies, reset its spawning timer and start the collision timer so that witchesOut decrements only once
	if (candy->hide == 0) {
        for (int i = 0; i < WITCHCOUNT2; i++) {
            if (witches2[i].hide == 0) {
                if (collision(candy->worldCol, candy->worldRow, candy->width, candy->height, witches2[i].worldCol, witches2[i].worldRow, witches2[i].width, witches2[i].height)) {
                    if (witches2[i].candyCollisionTimer == 0) {
                        playSoundB(witchScream_data, witchScream_length, 0);
                        witches2[i].candyCollisionTimer = 30;
                        witches2[i].hide = 1;
                        witches2[i].spawnTimer = 0;
                        witchesOut--;
                        candy->hide = 1;
                    }
                }
            }
        }
	}
}

void initWitches2() {
    for (int i = 0; i < WITCHCOUNT2; i++) {
        witches2[i].worldCol = 225;
        witches2[i].worldRow = 115;
        witches2[i].rdel = 1;
        witches2[i].cdel = 1;
        witches2[i].width = 16;
        witches2[i].height = 16;
        witches2[i].checkCollision = 1;
        witches2[i].movingPos = 3; //left 
        witches2[i].hide = 0;
        witches2[i].aniCounter = 0;
        witches2[i].curFrame = 0;
        witches2[i].numFrames = 2;
    }
}

void drawWitches2() {
    for (int i = 0; i < WITCHCOUNT2; i++) {
        if (witches2[i].hide == 1) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (witches2[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (witches2[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((witches2[i].movingPos - 1) * 2, (witches2[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateWitches2(WITCH* witch) {
    // spawn witch every 600 frames if they're inactive
    witch->spawnTimer++;
    if (witch->hide && witch->spawnTimer == 600) {
        witch->hide = 0;
        witch->spawnTimer = 0;
        witchesOut++;
    }

    // timer count down if they have been set
    if (witch->collisionTimer > 0) {
        witch->collisionTimer--;
    }
    if (witch->candyCollisionTimer > 0) {
        witch->candyCollisionTimer--;
    }

    // if the ghost collides with the witch a ghost buddy dies or you die if you have no buddies
    if (witch->hide == 0) {
        if (collision(witch->worldCol, witch->worldRow, witch->width, witch->height, ghost.worldCol, ghost.worldRow, ghost.width, ghost.height)) {
            if (witch->collisionTimer == 0){
                playSoundB(witchLaugh_data, witchLaugh_length, 0);
                witch->collisionTimer = 30;
                witch->hide = 1;
                witch->spawnTimer = 0;
                witchesOut--;
                if (ghostBuddies >= 1) {
                    ghostBuddies--;
                } else {
                    lostLevel2 = 1;
                }
            }
        }
    }

    moveWitch(witch, collisionmap2);
}

void initAnimals2() {
    for (int i = 0; i < ANIMALCOUNT2; i++) {
        animals2[i].worldCol = 225;
        animals2[i].worldRow = 115;
        animals2[i].rdel = 1;
        animals2[i].cdel = 1;
        animals2[i].width = 16;
        animals2[i].height = 16;
        animals2[i].movingPos = 2; // 1 for up, 2 for down, 3 for left, 4 for right
        animals2[i].checkCollision = 1;// 1 for collision and can't move there, 0 if no collision and can move there
        animals2[i].hide = 1;
        animals2[i].spriteType = rand() % 3 + 1;
        animals2[i].aniCounter = 0;
        animals2[i].curFrame = 0;
        animals2[i].numFrames = 2;
    }
}

void drawAnimals2() {
    for (int i = 0; i < ANIMALCOUNT2; i++) {
        if (animals2[i].hide == 1) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (animals2[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (animals2[i].worldCol - hOff)) | ATTR1_SMALL;
            if (animals2[i].spriteType == 1) { // bear
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals2[i].movingPos - 1) * 2) + 8, animals2[i].curFrame * 2);
            } else if (animals2[i].spriteType == 2) { // bunny
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals2[i].movingPos - 1) * 2) + 16, animals2[i].curFrame * 2);
            } else { // frog
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals2[i].movingPos - 1) * 2) + 24, animals2[i].curFrame * 2);
            }
        }
        shadowOAMIndex++;
    }
}

void updateAnimals2(ANIMALS* animals) {
    // spawn animals every 400 frames ONLY IF there are less witches out than started - so player HAS to kill witches before gaining ghost buddies
    animals->spawnTimer++;
    if (animals->hide && animals->spawnTimer >= 400 && witchesOut < 6) {
        animals->hide = 0;
        animals->spawnTimer = 0;
    }

    moveAnimals(animals, collisionmap2);
}

void drawScore2() {
    // for ghost buddies
    //first digit
    shadowOAM[shadowOAMIndex].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = 83 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_TILEID(((ghostBuddies % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 1].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 1].attr1 = 97 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 1].attr2 = ATTR2_TILEID((ghostBuddies % 10) * 2 , 8);

    //for candy
    //first digit
    shadowOAM[shadowOAMIndex + 2].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 2].attr1 = 210 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 2].attr2 = ATTR2_TILEID(((candyCount % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 3].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 3].attr1 = 224 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 3].attr2 = ATTR2_TILEID((candyCount % 10) * 2 , 8);

    shadowOAMIndex++;
}

// level ideas

// defeat wtiches first before trick-or-treaters come out bc they're scared?

// maybe once you got ghost buddies in level 1, you need to get food for the party? or maybe defeat the witches because the ghost
// buddies are too scared to come now

// maybe the witch took your knives and you have to collect them? 

// so defeat witches to get ghost buddies to come out, but they're still scared? have to go and knock on their door or leave candy
// to make them come out

// level 2
// YAY! you have ghost buddies now :) but you'll still need more to have your party!
// but wait! it's gotten darker out now and the witches have scared all the animals away!
// you need to start defeating the witches before the animals come out again!
// find the bats who are hiding somewhere in the forest to get candy first, and then defeat the witches. good luck!

// so in update bat, if candyCount == 0 or if some var foundBat == 0 then just make the bats move up and down in one spot (the circle area in the corner)
// if those variables are true, then update like normal
// for animals, maybe init and draw like normal but keep them hidden at first
// and then have a local var witchCount and if it is < some number, then spawn animals (so add another condition to the if statement)

// also increase num of ghost buddies to win, lessen the bat count, and see if you can speed up the witches
