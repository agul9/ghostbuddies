
//{{BLOCK(level3Inst)

//======================================================================
//
//	level3Inst, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 398 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12736 + 2048 = 15296
//
//	Time-stamp: 2021-12-13, 23:10:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL3INST_H
#define GRIT_LEVEL3INST_H

#define level3InstTilesLen 12736
extern const unsigned short level3InstTiles[6368];

#define level3InstMapLen 2048
extern const unsigned short level3InstMap[1024];

#define level3InstPalLen 512
extern const unsigned short level3InstPal[256];

#endif // GRIT_LEVEL3INST_H

//}}BLOCK(level3Inst)
