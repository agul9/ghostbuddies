// more general functions related to whole game play found in lib.h

// Constants
#define WITCHCOUNT 3
#define ANIMALCOUNT 10
#define BATCOUNT 3

// Variables
extern int lostLevel1;
extern int wonLevel1;
extern WITCH witches[WITCHCOUNT];
extern ANIMALS animals[ANIMALCOUNT];
extern BATS bats[BATCOUNT];

// Prototypes
void initLevel1();
void updateLevel1();
void drawLevel1();

void updatePlayer();

void updateKnives();

void initWitches();
void drawWitches();
void updateWitches(WITCH *);

void initBats();
void drawBats();
void updateBats(BATS *);

void updateCandy(ATTACKSPRITE *);

void initAnimals();
void drawAnimals();
void updateAnimals(ANIMALS *);

void drawScore();

