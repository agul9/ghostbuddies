
//{{BLOCK(inst2)

//======================================================================
//
//	inst2, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 245 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 7840 + 2048 = 10400
//
//	Time-stamp: 2021-12-14, 16:46:20
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INST2_H
#define GRIT_INST2_H

#define inst2TilesLen 7840
extern const unsigned short inst2Tiles[3920];

#define inst2MapLen 2048
extern const unsigned short inst2Map[1024];

#define inst2PalLen 512
extern const unsigned short inst2Pal[256];

#endif // GRIT_INST2_H

//}}BLOCK(inst2)
