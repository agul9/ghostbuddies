#include "myLib.h"
#include "level1.h"
#include "collisionmap1.h"

#include "sound.h"
#include "happyBat.h"
#include "killSound.h"
#include "witchScream.h"
#include "witchLaugh.h"

// Variables
int hOff;
int vOff;
int cheatOn; 
int candyCount;
int ghostBuddies;
int lostLevel1; // set to 1 when witch collides with ghost, and ghost buddies == 0
int wonLevel1; // set to 1 when you get 10 ghost buddies

OBJ_ATTR shadowOAM[128];
int shadowOAMIndex;

ANISPRITE ghost;
WITCH witches[WITCHCOUNT];
ATTACKSPRITE knives[KNIVESCOUNT];
ATTACKSPRITE candy[20];
ANIMALS animals[ANIMALCOUNT];
BATS bats[BATCOUNT];

unsigned char* collisionMap = collisionmap1Bitmap;

SOUND soundA;
SOUND soundB;

// Initialize the game
void initLevel1() {
    vOff = 96;
    hOff = 9;

    candyCount = 0;
    ghostBuddies = 0;
    wonLevel1 = 0;
    lostLevel1 = 0;
    cheatOn = 0;

    initPlayer(72, 172);
    initAttackSprites();
    initWitches();
    initBats();
    initAnimals();
}

// Updates the game each frame
void updateLevel1() {
	updatePlayer();
    animatePlayer();
    for (int i = 0; i < BATCOUNT; i++) {
        updateBats(&bats[i]);
        animateBats(&bats[i]);
    }
    for (int i = 0; i < KNIVESCOUNT; i++) {
        updateKnives(&knives[i]);
    }
    for (int i = 0; i < 20; i++) {
        updateCandy(&candy[i]);
    }
    for (int i = 0; i < WITCHCOUNT; i++) {
        updateWitches(&witches[i]);
        animateWitches(&witches[i]);
    }
    for (int i = 0; i < ANIMALCOUNT; i++) {
        updateAnimals(&animals[i]);
        animateAnimals(&animals[i]);
    }
}

// Draws the game each frame
void drawLevel1() {
    shadowOAMIndex = 0; 
    drawPlayer();
    drawWitches();
    drawKnives();
    drawCandy();
    drawBats();
    drawAnimals();
    drawScore();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG1HOFF = hOff;
    REG_BG1VOFF = vOff;
}

// Handle every-frame actions of the player
void updatePlayer() {
    if (ghostBuddies == 10) {
        wonLevel1 = 1;
    }

    if (BUTTON_HELD(BUTTON_R)) {
        cheatOn = 1;
    }

    if (BUTTON_PRESSED(BUTTON_B)) {
        // if cheat is on then the ghost can shoot four knives in all directions at once
        if (cheatOn) {
            throwKnives(1);
            throwKnives(2);
            throwKnives(3);
            throwKnives(4);
        } else {
            throwKnives(ghost.facePos);
        }
    }

    //can only throw candy if you have candy
    if (candyCount >= 1) {
        if (BUTTON_PRESSED(BUTTON_A)) {
            throwCandy(ghost.facePos);
        }
    }

    //if you run into a bats, you get candy, the bats disappears, and the timer starts again to determine when to spawn another bats
    for (int i = 0; i < BATCOUNT; i++) {
        if (bats[i].hide == 0) {
            if (collision(ghost.worldCol, ghost.worldRow, ghost.width, ghost.height, bats[i].worldCol, bats[i].worldRow, bats[i].width, bats[i].height)) {
                if (bats[i].candyTimer == 0) {
                    playSoundB(happyBat_data, happyBat_length, 0);
                    candyCount++;
                    bats[i].hide = 1;
                    bats[i].candyTimer = 50;
                    bats[i].spawnTimer = 0;
                }
            }
        }
    }

    movePlayer(collisionMap);
}

void initBats() {
    for (int i = 0; i < BATCOUNT; i++) {
        bats[i].worldCol = 208;
        bats[i].worldRow = 178;
        bats[i].rdel = 1;
        bats[i].cdel = 1;
        bats[i].width = 16;
        bats[i].height = 16;
        bats[i].facePos = 1; // 1 for up, 2 for down, 3 for left, 4 for right
        bats[i].checkCollision = 1;
        bats[i].hide = 0;
        bats[i].candyTimer = 0;
        bats[i].aniCounter = 0;
        bats[i].curFrame = 0;
        bats[i].numFrames = 2;
    }
}

void drawBats() {
    for (int i = 0; i < BATCOUNT; i++) {
        if (bats[i].hide) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (bats[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (bats[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((bats[i].facePos - 1) * 2) + 8, (bats[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateBats(BATS* bats) {
    bats->spawnTimer++;
    // spawn a new bats every 600 frames
    if (bats->hide && bats->spawnTimer == 600) {
        bats->hide = 0;
        bats->spawnTimer = 0;
    }
    if (bats->candyTimer > 0) {
        bats->candyTimer--;
    }

    moveBats(bats, collisionMap);
}


void updateKnives(ATTACKSPRITE* knife) {
    // timer for collision bt knife and animals
    if (knife->timer > 0) {
        knife->timer--;
    }
    
    // timer for cheat and having the knives kill the witches
    if (knife->timer2 > 0) {
        knife->timer2--;
    }

    shoot(knife);

    for (int i = 0; i < ANIMALCOUNT; i++) {
        if (animals[i].hide == 0 && knife->hide == 0) {
            if (collision(knife->worldCol, knife->worldRow, knife->width, knife->height, animals[i].worldCol, animals[i].worldRow, animals[i].width, animals[i].height)) {
                if (knife->timer == 0) {
                    playSoundB(killSound_data, killSound_length, 0);
                    knife->timer = 30;
                    knife->hide = 1;
                    animals[i].hide = 1;
                    animals[i].spawnTimer = 0;
                    ghostBuddies++;
                }
            }
        }
    }

    // if the cheat is on then the knives can kill the witches
    if (cheatOn) {
        for (int i = 0; i < WITCHCOUNT; i++) {
            if (witches[i].hide == 0 && knife->hide == 0) {
                if (collision(knife->worldCol, knife->worldRow, knife->width, knife->height, witches[i].worldCol, witches[i].worldRow, witches[i].width, witches[i].height)) {
                    if (knife->timer2 == 0) {
                        playSoundB(witchScream_data, witchScream_length, 0);
                        knife->timer2 = 30;
                        knife->hide = 1;
                        witches[i].hide = 1;
                        witches[i].spawnTimer = 0;
                    }
                }
            }
        }
    }
}

void updateCandy(ATTACKSPRITE* candy) {
    shoot(candy);

	if (candy->hide == 0) {
        for (int i = 0; i < WITCHCOUNT; i++) {
            if (witches[i].hide == 0) {
                if (collision(candy->worldCol, candy->worldRow, candy->width, candy->height, witches[i].worldCol, witches[i].worldRow, witches[i].width, witches[i].height)) {
                    playSoundB(witchScream_data, witchScream_length, 0);
                    witches[i].hide = 1;
                    witches[i].spawnTimer = 0;
                    candy->hide = 1;
                }
            }
        }
	}
}


void initWitches() {
    for (int i = 0; i < WITCHCOUNT; i++) {
        witches[i].worldCol = 225;
        witches[i].worldRow = 15;
        witches[i].rdel = 1;
        witches[i].cdel = 1;
        witches[i].width = 16;
        witches[i].height = 16;
        witches[i].checkCollision = 1;
        witches[i].movingPos = 3; //left 
        witches[i].hide = 0;
        witches[i].aniCounter = 0;
        witches[i].curFrame = 0;
        witches[i].numFrames = 2;
    }
}

void drawWitches() {
    for (int i = 0; i < WITCHCOUNT; i++) {
        if (witches[i].hide == 1) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (witches[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (witches[i].worldCol - hOff)) | ATTR1_SMALL;
            shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID((witches[i].movingPos - 1) * 2, (witches[i].curFrame * 2) + 4);
        }
        shadowOAMIndex++;
    }
}

void updateWitches(WITCH* witch) {
    // spawn witch every 600 frames if they're inactive
    witch->spawnTimer++;
    if (witch->hide && witch->spawnTimer == 600) {
        witch->hide = 0;
        witch->spawnTimer = 0;
    }
    if (witch->collisionTimer > 0) {
        witch->collisionTimer--;
    }

    //if the ghost collides with the witch a ghost buddy dies or you die if you have no buddies
    if (witch->hide == 0) {
        if (collision(witch->worldCol, witch->worldRow, witch->width, witch->height, ghost.worldCol, ghost.worldRow, ghost.width, ghost.height)) {
            if (witch->collisionTimer == 0){
                playSoundB(witchLaugh_data, witchLaugh_length, 0);
                witch->collisionTimer = 30;
                witch->hide = 1;
                witch->spawnTimer = 0;
                if (ghostBuddies >= 1) {
                    ghostBuddies--;
                } else {
                    lostLevel1 = 1;
                }
            }
        }
    }

    moveWitch(witch, collisionMap);
}

void initAnimals() {
    for (int i = 0; i < ANIMALCOUNT; i++) {
        animals[i].worldCol = 129;
        animals[i].worldRow = 164;
        animals[i].rdel = 1;
        animals[i].cdel = 1;
        animals[i].width = 16;
        animals[i].height = 16;
        animals[i].movingPos = 2; // 1 for up, 2 for down, 3 for left, 4 for right
        animals[i].checkCollision = 1;// 1 for collision and can't move there, 0 if no collision and can move there
        animals[i].hide = 0;
        animals[i].spriteType = rand() % 3 + 1;
        animals[i].aniCounter = 0;
        animals[i].curFrame = 0;
        animals[i].numFrames = 2;
    }
}

void drawAnimals() {
    for (int i = 0; i < ANIMALCOUNT; i++) {
        if (animals[i].hide == 1) {
            shadowOAM[shadowOAMIndex].attr0 |= ATTR0_HIDE;
        } else {
            shadowOAM[shadowOAMIndex].attr0 = (ROWMASK & (animals[i].worldRow - vOff)) | ATTR0_SQUARE;
            shadowOAM[shadowOAMIndex].attr1 = (COLMASK & (animals[i].worldCol - hOff)) | ATTR1_SMALL;
            if (animals[i].spriteType == 1) { // bear
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals[i].movingPos - 1) * 2) + 8, animals[i].curFrame * 2);
            } else if (animals[i].spriteType == 2) { // bunny
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals[i].movingPos - 1) * 2) + 16, animals[i].curFrame * 2);
            } else { // frog
                shadowOAM[shadowOAMIndex].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(((animals[i].movingPos - 1) * 2) + 24, animals[i].curFrame * 2);
            }
        }
        shadowOAMIndex++;
    }
}

void updateAnimals(ANIMALS* animals) {
    animals->spawnTimer++;
    if (animals->hide && animals->spawnTimer == 600) {
        animals->hide = 0;
        animals->spawnTimer = 0;
    }

    moveAnimals(animals, collisionMap);
}

void drawScore() {
    // for ghost buddies
    //first digit
    shadowOAM[shadowOAMIndex].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex].attr1 = 83 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex].attr2 = ATTR2_TILEID(((ghostBuddies % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 1].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 1].attr1 = 97 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 1].attr2 = ATTR2_TILEID((ghostBuddies % 10) * 2 , 8);

    //for candy
    //first digit
    shadowOAM[shadowOAMIndex + 2].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 2].attr1 = 210 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 2].attr2 = ATTR2_TILEID(((candyCount % 100) / 10) * 2 , 8);
    //second digit
    shadowOAM[shadowOAMIndex + 3].attr0 = 144 | ATTR0_SQUARE;
    shadowOAM[shadowOAMIndex + 3].attr1 = 224 | ATTR1_SMALL;
    shadowOAM[shadowOAMIndex + 3].attr2 = ATTR2_TILEID((candyCount % 10) * 2 , 8);

    shadowOAMIndex++;
}
