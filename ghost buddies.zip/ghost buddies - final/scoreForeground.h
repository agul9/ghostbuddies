
//{{BLOCK(scoreForeground)

//======================================================================
//
//	scoreForeground, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 30 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 960 + 2048 = 3520
//
//	Time-stamp: 2021-11-28, 18:58:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SCOREFOREGROUND_H
#define GRIT_SCOREFOREGROUND_H

#define scoreForegroundTilesLen 960
extern const unsigned short scoreForegroundTiles[480];

#define scoreForegroundMapLen 2048
extern const unsigned short scoreForegroundMap[1024];

#define scoreForegroundPalLen 512
extern const unsigned short scoreForegroundPal[256];

#endif // GRIT_SCOREFOREGROUND_H

//}}BLOCK(scoreForeground)
