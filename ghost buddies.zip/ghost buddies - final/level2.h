// more general functions related to whole game play found in lib.h

// Constants
#define WITCHCOUNT2 7
#define ANIMALCOUNT2 5
#define BATCOUNT2 5

// Variables
extern int lostLevel2;
extern int wonLevel2;
extern WITCH witches2[WITCHCOUNT2];
extern ANIMALS animals2[ANIMALCOUNT2];
extern BATS bats2[BATCOUNT2];

// Prototypes
void initLevel2();
void updateLevel2();
void drawLevel2();

void updatePlayer2();

void updateKnives2();

void initWitches2();
void drawWitches2();
void updateWitches2(WITCH *);

void initBats2();
void drawBats2();
void updateBats2(BATS *);

void updateCandy2(ATTACKSPRITE *);

void initAnimals2();
void drawAnimals2();
void updateAnimals2(ANIMALS *);

void drawScore2();

