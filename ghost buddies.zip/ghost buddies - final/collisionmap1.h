
//{{BLOCK(collisionmap1)

//======================================================================
//
//	collisionmap1, 512x256@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 131072 = 131584
//
//	Time-stamp: 2021-12-13, 01:03:41
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP1_H
#define GRIT_COLLISIONMAP1_H

#define collisionmap1BitmapLen 131072
extern const unsigned short collisionmap1Bitmap[65536];

#define collisionmap1PalLen 512
extern const unsigned short collisionmap1Pal[256];

#endif // GRIT_COLLISIONMAP1_H

//}}BLOCK(collisionmap1)
