
//{{BLOCK(scoreForegroundLevel3)

//======================================================================
//
//	scoreForegroundLevel3, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 29 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 928 + 2048 = 3488
//
//	Time-stamp: 2021-12-13, 23:10:55
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SCOREFOREGROUNDLEVEL3_H
#define GRIT_SCOREFOREGROUNDLEVEL3_H

#define scoreForegroundLevel3TilesLen 928
extern const unsigned short scoreForegroundLevel3Tiles[464];

#define scoreForegroundLevel3MapLen 2048
extern const unsigned short scoreForegroundLevel3Map[1024];

#define scoreForegroundLevel3PalLen 512
extern const unsigned short scoreForegroundLevel3Pal[256];

#endif // GRIT_SCOREFOREGROUNDLEVEL3_H

//}}BLOCK(scoreForegroundLevel3)
