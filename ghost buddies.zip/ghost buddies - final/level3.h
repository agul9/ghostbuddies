// more general functions related to whole game play found in lib.h

// Constants
#define WITCHCOUNT3 7
#define BATCOUNT3 10
#define CANDYPLACEDCOUNT 8

// Variables
extern int lostLevel3;
extern int wonLevel3;
extern WITCH witches3[WITCHCOUNT3];
extern BATS bats3[BATCOUNT3];
extern ATTACKSPRITE candyPlaced[CANDYPLACEDCOUNT];

// Prototypes
void initLevel3();
void updateLevel3();
void drawLevel3();

void updatePlayer3();

void updateKnives3();

void initWitches3();
void drawWitches3();
void updateWitches3(WITCH *);

void initBats3();
void drawBats3();
void updateBats3(BATS *);

void updateCandy3(ATTACKSPRITE *);

void initCandyPlaced();
void updateCandyPlaced(ATTACKSPRITE *);
void drawCandyPlaced();
void animateCandyPlaced();

void drawScore3();

