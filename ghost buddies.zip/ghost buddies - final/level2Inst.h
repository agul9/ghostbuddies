
//{{BLOCK(level2Inst)

//======================================================================
//
//	level2Inst, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 337 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 10784 + 2048 = 13344
//
//	Time-stamp: 2021-12-14, 16:47:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2INST_H
#define GRIT_LEVEL2INST_H

#define level2InstTilesLen 10784
extern const unsigned short level2InstTiles[5392];

#define level2InstMapLen 2048
extern const unsigned short level2InstMap[1024];

#define level2InstPalLen 512
extern const unsigned short level2InstPal[256];

#endif // GRIT_LEVEL2INST_H

//}}BLOCK(level2Inst)
